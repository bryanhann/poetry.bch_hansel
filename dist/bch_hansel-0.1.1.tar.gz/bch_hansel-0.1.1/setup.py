# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bch_hansel']

package_data = \
{'': ['*']}

install_requires = \
['bch_config @ git+https://github.com/bryanhann/poetry.bch_config@v0.1.1',
 'bch_inject @ git+https://github.com/bryanhann/poetry.bch_inject@0.1.2']

entry_points = \
{'console_scripts': ['bch-hansel = bch_hansel.console:hansel']}

setup_kwargs = {
    'name': 'bch-hansel',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'Bryan Hann',
    'author_email': 'nobody@nowhere',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
